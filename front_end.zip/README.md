
함수 작성 방법 : function Name(){}

폴더 : 카멜 케이스 ex) authoController.jsx

파일 
-기본 : 카멜 케이스 ex) authoController.jsx
-상수 관련 : 대문자 ex) COUNT.jsx

-class : 파스칼 ex) CuteCat()

-id(css) : 카멜 케이스 ex) cuteCat
