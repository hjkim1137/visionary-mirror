import React from 'react';
import SignUpCompo from '../components/SignUp/SignUpCompo';

function SignUp() {
  return <SignUpCompo></SignUpCompo>;
}

export default SignUp;
