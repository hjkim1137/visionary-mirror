import React from 'react';
import MyVisionGrid from '../components/MyVisionBoardGrid/MyVisionGrid';

function MyVisionBoardGrid() {
  return <MyVisionGrid></MyVisionGrid>;
}

export default MyVisionBoardGrid;
