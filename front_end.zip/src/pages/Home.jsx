import React from 'react';
import HomeCompo from '../components/Home/HomeCompo';

function Home() {
  return <HomeCompo></HomeCompo>;
}

export default Home;
