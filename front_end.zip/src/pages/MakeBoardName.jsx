import React from 'react';
import MakeBoardNameCompo from '../components/MakeBoardName/MakeBoardNameCompo';

function MakeBoardName() {
  return <MakeBoardNameCompo></MakeBoardNameCompo>;
}

export default MakeBoardName;
