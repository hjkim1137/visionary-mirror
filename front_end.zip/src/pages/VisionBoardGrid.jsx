import React from 'react';
import VisionGrid from '../components/VisionBoardGrid/VisionGrid';

function VisionBoardGrid() {
  return <VisionGrid></VisionGrid>;
}

export default VisionBoardGrid;
