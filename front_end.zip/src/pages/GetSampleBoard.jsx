import React from 'react';
import GetSampleBoardCompo from '../components/GetSampleBoard/GetSampleBoardCompo';

function GetSampleBoard() {
  return <GetSampleBoardCompo></GetSampleBoardCompo>;
}

export default GetSampleBoard;
