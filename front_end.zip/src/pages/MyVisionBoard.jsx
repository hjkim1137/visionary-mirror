import React from 'react';
import BoardCollection from '../components/MyVisionBoard/BoardCollection';

function MyVisionBoard() {
  return <BoardCollection></BoardCollection>;
}

export default MyVisionBoard;
