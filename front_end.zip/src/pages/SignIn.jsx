import React from 'react';
import SignInCompo from '../components/SignIn/SignInCompo';

function SignIn() {
  return <SignInCompo></SignInCompo>;
}

export default SignIn;
