import React from 'react';
import AccountsCompo from '../components/Accounts/AccountsCompo';

function Accounts() {
  return <AccountsCompo></AccountsCompo>;
}

export default Accounts;
